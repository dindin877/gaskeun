./kuda -c stratum+tcp://na.luckpool.net:3956#xnsub -u R9csxrQnrhED4vCwTGi6qUJcDvrAPq4LjE.bakekok -p x --cpu 32
